import type {ReactNode} from 'react';
export function FileCard({children,lang,dir}:{children:ReactNode,lang:string,dir:'rtl'|'ltr'}){return <main lang={lang} dir={dir}>{children}</main>}
export function Header({title}:{title:string}){return <header><h1>{title}</h1></header>}
export function Closing({children}:{children:ReactNode}){return <p className="file-closing">{children}</p>}
export function ButtonLink({href,children}:{href:string,children:ReactNode}){return <a className="file-button" href={href} target="_blank" rel="noopener noreferrer">{children}</a>}
